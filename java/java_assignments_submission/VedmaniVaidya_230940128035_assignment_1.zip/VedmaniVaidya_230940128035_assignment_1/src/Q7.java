
public class Q7 {

	public static void main(String[] args) {
	  int a,b,c;
	  a = 10;
	  b = 20;
	  c = 30;
	  int max;
	  if(a>=b && a>=c) {
		  max = a;
	  }
	  else if(b>=a && b>=c) {
		  max = b;
	  }else {
		  max = c;
	  }

	}

}

package Q1;

public class App {
    public static void main(String[] args) {
        Student s1 = new Student();
        Student s2 = new Student("Ramesh",01,06,2001);
        System.out.println(s1.show());
        System.out.println(s2.show());
    }
}

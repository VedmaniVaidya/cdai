package Q2;

public class App {
    public static void main(String[] args) {
        SalesPerson s1 = new SalesPerson(1, "Ramesh", 20, 01, 2000, 48, 1000, 100, 100);
        System.out.println(s1);
    }
}

